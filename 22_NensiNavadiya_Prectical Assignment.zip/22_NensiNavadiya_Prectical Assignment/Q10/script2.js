// User-defined script 2
console.log('Running user-defined script 2');
// Your custom code for script 2 goes here
